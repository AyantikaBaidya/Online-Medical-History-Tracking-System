<?php
    session_start();    
    $connection=mysqli_connect("localhost","root","");
    $db=mysqli_select_db($connection,"login_register_pure_coding");
    $query="select * from user where id=$_SESSION[id]";
	$date=" ";
    $status=" ";
    
    $query_run=mysqli_query($connection,$query);
    while($row=mysqli_fetch_assoc($query_run)){
        $date=$row['date'];
        $status=$row['status'];
		
    }
?>
<html>
<head>
<title> UPDATE DATA FORM</title>
</head>
<style>
body{
background-image:
url("health.jpg");
background-repeat: no-repeat;
background-size: cover;
}
</style>
<body>
<h1 align="center"> UPDATE DATA</h1>
<form align="center" action="" method="POST">
	<label for="date">Date of Appointment*:</label>
	<input type="text" id="date" name="date" value="<?php echo $date;?>">
	<br>
	<br>
	<label for="status">Appointment Booking Status*:</label>
	<input type="text" id="status" name="status" value="<?php echo $status;?>">
	<br>
	<br>
	
	<button type="submit" name="button">Update</button>
	<?php 
        

       
         if(isset($_POST['button'])){
			 
                        $connection=mysqli_connect("localhost","root","");
						$db=mysqli_select_db($connection,"login_register_pure_coding");
                        $query="update user set date='$_POST[date]',status='$_POST[status]' where id=$_SESSION[id];";
                        $query_run=mysqli_query($connection,$query);
                        echo '<script>alert("Successfully updated")
						location.href="welcome.php";
                        </script>';
                    }
                    
    ?>
</form>
</body>
</html>