<?php
    session_start();    
    $connection=mysqli_connect("localhost","root","");
    $db=mysqli_select_db($connection,"login_register_pure_coding");
    $query="select * from user where id=$_SESSION[id]";
	$pressure=" ";
    $pulse=" ";
    $weight=" ";
    $medicine=" ";
	$tests=" ";
	$date=" ";
	$status=" ";
    $query_run=mysqli_query($connection,$query);
    while($row=mysqli_fetch_assoc($query_run)){
        $pressure=$row['pressure'];
        $pulse=$row['pulse'];
		$weight=$row['weight'];
		$medicine=$row['medicine'];
		$tests=$row['tests'];
		$date=$row['date'];
		$status=$row['status'];
	}
?>
<html>
<head>
<title> UPDATE DATA FORM</title>
</head>
<style>
body{
background-image:
url("health.jpg");
background-repeat: no-repeat;
background-size: cover;
}
</style>
<body>
<h1 align="center"> UPDATE PRESCRIPTION </h1>
<form align="center" action="" method="POST">
	<label for="pressure">Blood Pressure*:</label>
	<input type="text" id="pressure" name="pressure" value="<?php echo $pressure;?>">
	<br>
	<br>
	<label for="pulse">Pulse Rate*:</label>
	<input type="text" id="pulse" name="pulse" value="<?php echo $pulse;?>">
	<br>
	<br>
	<label for="weight">Weight*:</label>
	<input type="text" id="weight" name="weight" value="<?php echo $weight;?>">
	<br>
	<br>
	<label for="medicine">Medications*:</label>
	<input type="text" id="medicine" name="medicine" value="<?php echo $medicine;?>">
	<br>
	<br>
	<label for="tests">Recommended Tests*:</label>
	<input type="text" id="tests" name="tests" value="<?php echo $tests;?>">
	<br>
	<br>
	<label for="tests">Date of Appointment*:</label>
	<input type="text" id="date" name="date" value="<?php echo $date;?>">
	<br>
	<br>
	<label for="tests">Appintment Booking Status*:</label>
	<input type="text" id="status" name="status" value="<?php echo $status;?>">
	
	
	<button type="submit" name="button">Update</button>
	<?php 
        

       
         if(isset($_POST['button'])){
			 
                        $connection=mysqli_connect("localhost","root","");
						$db=mysqli_select_db($connection,"login_register_pure_coding");
                        $query="update user set pressure='$_POST[pressure]',pulse='$_POST[pulse]',weight='$_POST[weight]',medicine='$_POST[medicine]',tests='$_POST[tests]',date='$_POST[date]',status='$_POST[status]' where id=$_SESSION[id];";
                        $query_run=mysqli_query($connection,$query);
                        echo '<script>alert("Successfully updated")
						location.href="welcome1.php";
                        </script>';
                    }
                    
                ?>
</form>
</body>
</html>