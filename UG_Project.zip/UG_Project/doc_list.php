<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Doctor Data</h2>
         
  <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Doctor Name</th>
        <th>Specialization</th>
      </tr>
    </thead>
    <tbody>
<?php

$server = "localhost";
$user = "root";
$pass = "";
$database = "login_register_pure_coding";

$conn = mysqli_connect($server, $user, $pass, $database);
$sql= "select * from doctor";
$result= mysqli_query($conn,$sql);
$row= mysqli_fetch_assoc($result);
while($row= mysqli_fetch_assoc($result))
{
$id= $row['id'];
    echo '<tr>';
echo '<td>'.$row['id'].'</td>';
echo '<td>'.$row['username'].'</td>';
echo '<td>'.$row['specialization'].'</td>';
echo "<td><a href='app_update.php'?id=$id'<button type='button' class='btn btn-info'>Update</button></td>";
echo "<td><a href='appoint.php'?id=$id'<button type='button' class='btn btn-info'>Check Appointments</button></td>";
}
?>
</tbody>
  </table>
</div>

</body>
</html>