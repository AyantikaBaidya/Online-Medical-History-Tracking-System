<!DOCTYPE html>
<html lang="en">
<head>
  <title>Patient Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Patient Data</h2>
         
  <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>DOB</th>
      </tr>
    </thead>
    <tbody>
<?php

$server = "localhost";
$user = "root";
$pass = "";
$database = "login_register_pure_coding";

$conn = mysqli_connect($server, $user, $pass, $database);
$sql= "select * from user where id=$id";
$result= mysqli_query($conn,$sql);

while($row= mysqli_fetch_assoc($result))
{
$id= $row['id'];
    echo '<tr>';
echo '<td>'.$row['id'].'</td>';
echo '<td>'.$row['username'].'</td>';
echo '<td>'.$row['dob'].'</td>';
echo "<td><a href='view.php'?id=$id'<button type='button' class='btn btn-info'>View</button></td>";

}
?>
</tbody>
</table>
</div>

</body>
</html>