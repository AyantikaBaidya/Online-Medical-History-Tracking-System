<!DOCTYPE html>
<html lang="en">
<head>
  <title>Patient Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Appointment Data</h2>
         
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Date</th>
        <th>Dr. Ajit Sen</th>
        <th>Dr. Riya Ghosh</th>
		<th>Dr. Akash Jain</th>
		<th>Dr. Rishi Das</th>
		<th>Dr. Puja Kumari</th>
		<th>Dr. Radha Gupta</th>
		<th>Dr. Mukesh Rao</th>
      </tr>
    </thead>
    <tbody>
<?php

$server = "localhost";
$user = "root";
$pass = "";
$database = "login_register_pure_coding";

$conn = mysqli_connect($server, $user, $pass, $database);
$sql= "select * from appoint";
$result= mysqli_query($conn,$sql);
$row= mysqli_fetch_assoc($result);
while($row= mysqli_fetch_assoc($result))
{
$id= $row['id'];
    echo '<tr>';
echo '<td>'.$row['date'].'</td>';
echo '<td>'.$row['ajit'].'</td>';
echo '<td>'.$row['riya'].'</td>';
echo '<td>'.$row['akash'].'</td>';
echo '<td>'.$row['rishi'].'</td>';
echo '<td>'.$row['puja'].'</td>';
echo '<td>'.$row['radha'].'</td>';
echo '<td>'.$row['mukesh'].'</td>';

}
?>
</tbody>
  </table>
</div>

</body>
</html>