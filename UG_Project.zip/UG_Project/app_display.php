<?php 

session_start();

if (isset($_SESSION['ajit'])&& isset($_SESSION['riya'])&& isset($_SESSION['akash'])&& isset($_SESSION['rishi'])&&isset($_SESSION['puja'])&&isset($_SESSION['radha'])&&isset($_SESSION['mukesh']))  {
    header("Location: appoint_check.php");
}

?>
<?php
    session_start();    
    $connection=mysqli_connect("localhost","root","");
    $db=mysqli_select_db($connection,"login_register_pure_coding");
    $query="select * from appoint where id=$_SESSION[id]";
	$ajit=" ";
	$riya=" ";
    $akash=" ";
    $rishi=" ";
    $puja=" ";
	$radha=" ";
	$mukesh=" ";
		
    $query_run=mysqli_query($connection,$query);
    while($row=mysqli_fetch_assoc($query_run)){
        $ajit=$row['ajit'];
        $riya=$row['riya'];
		$akash=$row['akash'];
		$rishi=$row['rishi'];
		$puja=$row['puja'];
		$radha=$row['radha'];
		$mukesh=$row['mukesh'];
        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


	<link rel="stylesheet" type="text/css" href="button.css">
    <title>Welcome</title>
</head>
<body>
<style>
th ,td{
	font-size:24px;
	background:white;
	color:black;
}
body{
background-image:
url("pic11.jpg");
background-repeat: no-repeat;
background-size: cover;
}
h1{
	color:Cornsilk;

}

	
	</style>
<h1 align="center">Patient Details</h1>
<font>
<table border="2px"  width="50%" align="center" style= "border-color:red; border-collapse:collapse">


<tr>
    <?php echo "<tr>"."<th>Dr. Ajit Sen</th>" ."<td> " . $_SESSION['ajit'] . "</td>"."</tr>"; 
	echo "<tr>"."<th>Dr. Riya Ghosh</th>"."<td> " . $_SESSION['riya'] . "</td>"."</tr>";
	echo "<tr>"."<th>Dr. Akash Jain</th>"."<td> " . $_SESSION['akash'] . "</td>"."</tr>";

	echo "<tr>"."<th>Dr. Rishi Das</th>"."<td> " . $_SESSION['rishi'] . "</td>"."</tr>";
	echo "<tr>"."<th>Dr. Puja Kumari</th>"."<td> " . $_SESSION['puja'] . "</td>"."</tr>";
	echo "<tr>"."<th>Dr. Radha Gupta</th>"."<td> " . $_SESSION['radha'] . "</td>"."</tr>";
	echo "<tr>"."<th>Dr. Mukesh Rao</th>"."<td> " . $_SESSION['mukesh'] . "</td>"."</tr>";


	
	?>
	</tr>
	</table>
	<table border="2px" width="50%" align="center" style= "border-color:red; border-collapse:collapse" >
	<tr>
	
	<th><br><button class="button1"> <a href="form.php">UPDATE</a></button></br></th>
	

    <th><br><button><a href="logout3.php">LOGOUT</a></button></br></th>
	</tr>
	</table>
	
</font>
	
	
</body>

</html>
</html>