<?php 

include 'config.php';

error_reporting(0);
if (isset($_SESSION['ajit'])&& isset($_SESSION['riya'])&& isset($_SESSION['akash'])&& isset($_SESSION['rishi'])&&isset($_SESSION['puja'])&&isset($_SESSION['radha'])&&isset($_SESSION['mukesh']))  {
    header("Location: app_dis.php");
}
session_start();

if (isset($_SESSION['ajit'])) {
    header("Location: appoint_check.php");
}

if (isset($_POST['submit'])) {
	
	$date = $_POST['date'];
	$ajit = $_POST['ajit'];
	$riya = $_POST['riya'];
	$akash = $_POST['akash'];
	$rishi = $_POST['rishi'];
	$puja = $_POST['puja'];
	$radha = $_POST['radha'];
	$mukesh = $_POST['mukesh'];
	
		$sql = "SELECT * FROM appoint WHERE date='$date'";
		$result = mysqli_query($conn, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO appoint (date, ajit, riya, akash , rishi, puja, radha, mukesh)
					VALUES ('$date','$ajit','$riya','$akash','$rishi','$puja','$radha','$mukesh')";
			$result = mysqli_query($conn, $sql);
			if ($result) {
				echo "<script>alert('Wow! Appointment Count Completed.')</script>";
				$ajit = "";
				$date = "";
				
			} else {
				echo "<script>alert('Woops! Something Wrong Went.')</script>";
			}
		} else {
			echo "<script>alert('Woops! date Already Exists.')</script>";
		}
		 
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Register Form - Pure Coding</title>
</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-date">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Update </p>
			
			
			<div class="input-group">
				<input type="text" placeholder="Date" name="date" value="<?php echo $date; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Dr. Ajit Sen" name="ajit" value="<?php echo $ajit; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Dr. Riya Ghosh" name="riya" value="<?php echo $riya; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Dr. Akash Jain" name="akash" value="<?php echo $akash; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Dr. Rishi Das" name="rishi" value="<?php echo $rishi; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Dr. Puja Kumari" name="puja" value="<?php echo $puja; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Dr. Radha Gupta" name="radha" value="<?php echo $radha; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Dr. Mukesh Rao" name="mukesh" value="<?php echo $mukesh; ?>" required>
			</div>
			
			<div class="input-group">
				<button name="submit" class="btn">Update</button>
			</div>
			<div class="input-group">
				<button type="reset" name="reset" value ="Reset" class="btn">Reset</button>
			</div>
			<p class="login-register-text">Want to check Appointments? <a href="app_dis.php">Check Appointments</a>.</p>
			<p class="login-register-text">Want to go to Home page? <a href="home.html">Home Page</a>.</p>
		</form>
	</div>
</body>
</html>