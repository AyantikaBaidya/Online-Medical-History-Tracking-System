<?php 

session_start();

if (isset($_SESSION['username'])&& isset($_SESSION['dob'])&& isset($_SESSION['gender'])&& isset($_SESSION['blood_group'])&&isset($_SESSION['number'])&&isset($_SESSION['disease'])&&isset($_SESSION['symptoms'])&&isset($_SESSION['pressure'])&&isset($_SESSION['pulse'])&&isset($_SESSION['weight'])&&isset($_SESSION['medicine'])&&isset($_SESSION['tests'])&&isset($_SESSION['date'])&&isset($_SESSION['status'])) {
    header("Location: doc.php");
}

?>
<?php
    session_start();    
    $connection=mysqli_connect("localhost","root","");
    $db=mysqli_select_db($connection,"login_register_pure_coding");
    $query="select * from user where id=$_SESSION[id]";
	$name=" ";
	$gender=" ";
    $dob=" ";
    $number=" ";
    $disease=" ";
	$symptoms=" ";
	$pressure=" ";
	$pulse=" ";
    $weight=" ";
    $medicine=" ";
    $tests=" ";
	$date=" ";
	$status=" ";
	
    $query_run=mysqli_query($connection,$query);
    while($row=mysqli_fetch_assoc($query_run)){
		 $name=$row['username'];
        $dob=$row['dob'];
		$number=$row['number'];
		$disease=$row['disease'];
		$symptoms=$row['symptoms'];
		$gender=$row['gender'];
        $pressure=$row['pressure'];
        $pulse=$row['pulse'];
		$weight=$row['weight'];
		$medicine=$row['medicine'];
		$tests=$row['tests'];
		$date=$row['date'];
		$status=$row['status'];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


	<link rel="stylesheet" type="text/css" href="button.css">
    <title>Welcome</title>
</head>
<body>
<style>
th ,td{
	font-size:24px;
	background:white;
	color:black;
}
body{
background-image:
url("pic11.jpg");
background-repeat: no-repeat;
background-size: cover;
}
h1{
	color:Cornsilk;

}

	
	</style>
<h1 align="center">Patient Details</h1>
<font>
<table border="2px"  width="50%" align="center" style= "border-color:red; border-collapse:collapse">


<tr>
    <?php echo "<tr>"."<th>Patient name</th>" ."<td> " . $_SESSION['username'] . "</td>"."</tr>"; 
	echo "<tr>"."<th>DOB</th>"."<td> " . $_SESSION['dob'] . "</td>"."</tr>";
	echo "<tr>"."<th>Gender</th>"."<td> " . $_SESSION['gender'] . "</td>"."</tr>";

	echo "<tr>"."<th>Number</th>"."<td> " . $_SESSION['number'] . "</td>"."</tr>";
	echo "<tr>"."<th>Disease</th>"."<td> " . $_SESSION['disease'] . "</td>"."</tr>";
	echo "<tr>"."<th>Symptoms</th>"."<td> " . $_SESSION['symptoms'] . "</td>"."</tr>";


	
	?>
	</tr>
	</table>
	<table border="2px" width="50%" align="center" style= "border-color:red; border-collapse:collapse" >
	<tr>
	
	

    <th><br><button><a href="log1.php">LOGOUT</a></button></br></th>
	</tr>
	</table>
	<h1 align="center">Patient Medical Details</h1>
<table border="2px"  width="50%" align="center" style= "border-color:red; border-collapse:collapse">


<tr>
    <?php echo "<tr>"."<th>Blood Pressure</th>" ."<td> " . $_SESSION['pressure'] . "</td>"."</tr>"; 
	echo "<tr>"."<th>Pulse Rate</th>"."<td> " . $_SESSION['pulse'] . "</td>"."</tr>";
	echo "<tr>"."<th>Weight</th>"."<td> " . $_SESSION['weight'] . "</td>"."</tr>";

	echo "<tr>"."<th>Medications</th>"."<td> " . $_SESSION['medicine'] . "</td>"."</tr>";
	echo "<tr>"."<th>Recommended Tests</th>"."<td> " . $_SESSION['tests'] . "</td>"."</tr>";
	echo "<tr>"."<th>Date of Appointment</th>"."<td> " . $_SESSION['date'] . "</td>"."</tr>";
	echo "<tr>"."<th>Appintment Booking Status</th>"."<td> " . $_SESSION['status'] . "</td>"."</tr>";
	
	
	?>
	</tr>
	<tr>
	
	<th><br><button class="button1"> <a href="doc_form.php">PRESCIBE</a></button></br></th>
	</tr>
	</table>
</font>
	
</body>

</html>
</html>