<?php
    session_start();    
    $connection=mysqli_connect("localhost","root","");
    $db=mysqli_select_db($connection,"login_register_pure_coding");
    $query="select * from user where id=$_SESSION[id]";
	$name=" ";
    $dob=" ";
    $number=" ";
    $disease=" ";
	$symptoms=" ";
    $query_run=mysqli_query($connection,$query);
    while($row=mysqli_fetch_assoc($query_run)){
        $name=$row['username'];
        $dob=$row['dob'];
		$number=$row['number'];
		$disease=$row['disease'];
		$symptoms=$row['symptoms'];
    }
?>
<html>
<head>
<title> UPDATE DATA FORM</title>
</head>
<style>
body{
background-image:
url("health.jpg");
background-repeat: no-repeat;
background-size: cover;
}
</style>
<body>
<h1 align="center"> UPDATE DATA</h1>
<form align="center" action="" method="POST">
	<label for="fname">Name of the Candidate*:</label>
	<input type="text" id="fname" name="name" value="<?php echo $name;?>">
	<br>
	<br>
	<label for="Dob">Date of Birth(DOB)*:</label>
	<input type="text" id="Dob" name="dob" value="<?php echo $dob;?>">
	<br>
	<br>

	<label for="email">Number*:</label>
	<input type="text" id="number" name="number" value="<?php echo $number;?>">
	<br>
	<br>
	<label for="email">Disease*:</label>
	<input type="text" id="disease" name="disease" value="<?php echo $disease;?>">
	<br>
	<br>
	<label for="email">Symptoms*:</label>
	<input type="text" id="symptoms" name="symptoms" value="<?php echo $symptoms;?>">
	

	
	<button type="submit" name="button">Update</button>
	<?php 
        

       
         if(isset($_POST['button'])){
			 
                        $connection=mysqli_connect("localhost","root","");
						$db=mysqli_select_db($connection,"login_register_pure_coding");
                        $query="update user set username='$_POST[name]',dob='$_POST[dob]',number='$_POST[number]',disease='$_POST[disease]',symptoms='$_POST[symptoms]' where id=$_SESSION[id];";
                        $query_run=mysqli_query($connection,$query);
                        echo '<script>alert("Successfully updated")
						location.href="welcome.php";
                        </script>';
                    }
                    
                ?>
</form>
</body>
</html>