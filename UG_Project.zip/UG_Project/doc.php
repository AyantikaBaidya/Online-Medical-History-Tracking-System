<?php 

include 'config.php';

session_start();

error_reporting(0);
if (isset($_SESSION['username'])&& isset($_SESSION['dob'])&& isset($_SESSION['gender'])&& isset($_SESSION['blood_group'])&&isset($_SESSION['number'])&&isset($_SESSION['disease'])&&isset($_SESSION['symptoms'])&&isset($_SESSION['pressure'])&&isset($_SESSION['pulse'])&&isset($_SESSION['weight'])&&isset($_SESSION['medicine'])&&isset($_SESSION['tests'])&&isset($_SESSION['date'])&&isset($_SESSION['status'])) {
    header("Location: welcome1.php");
}

if (isset($_POST['submit'])) {
	$email = $_POST['email'];

	$sql = "SELECT * FROM user WHERE email='$email' ";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		$_SESSION['dob'] = $row['dob'];
		$_SESSION['gender']=$row['gender'];
	    $_SESSION['id']=$row['id'];
		$_SESSION['number'] = $row['number'];
		$_SESSION['disease'] = $row['disease'];
		$_SESSION['symptoms'] = $row['symptoms'];
		$_SESSION['pressure'] = $row['pressure'];
		$_SESSION['pulse'] = $row['pulse'];
		$_SESSION['weight'] = $row['weight'];
		$_SESSION['medicine'] = $row['medicine'];
		$_SESSION['tests'] = $row['tests'];
		$_SESSION['date'] = $row['date'];
		$_SESSION['status'] = $row['status'];
		
		header("Location: welcome1.php");
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Login Form - Pure Coding</title>
</head>

</style>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Patient-Record</p>
			<div class="input-group">
				<input type="email" placeholder="Patient-Email" name="email" value="<?php echo $email; ?>" required>
			
			<div class="input-group">
				<button name="submit" class="btn">Check Record</button>
			</div>
			
			<p class="login-register-text">Want to Check Patient List ? <a href="display.php">Patient List</a>.</p>
			<p class="login-register-text">Want to Logout ? <a href="doc_login.php">Logout</a>.</p>
		
		</form>
	</div>
</body>
</html>